package Accountin;

public class Stuff {

	 private double salaryPerHour;

	    // Constructor
	    public Stuff(String name, double salaryPerHour) {
	        super();
	        this.salaryPerHour = salaryPerHour;
	    }

	    public double getSalary() {
	        // Calculate salary based on hours worked (let's say 40 hours per week)
	        return salaryPerHour * 50;
	    }

	    public double getSalaryPerHour() {
	        return salaryPerHour;
	    }

	    public void setSalaryPerHour(double salaryPerHour) {
	        this.salaryPerHour = salaryPerHour;
	    }

	    public void serve() {
	        System.out.println(getName() + " is serving.");
	    }

		String getName() {
			// TODO Auto-generated method stub
			return null;
		}

}
