package Accountin;

public class Student extends Person_ab {

    private String studentId;

    // Constructor
    public Student(String name, String studentId) {
        super();
        this.studentId = studentId;
    }

    @Override
    public double getSalary() {
        // Students don't have a salary, so return 0
        return 0;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    // Additional method specific to Student
    public void study() {
        System.out.println(getName() + " is studying.");
    }

}
