package Accountin;

public class Main  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		    Student student = new Student("Karim", "S123");
	        Teacher teacher = new Teacher("Rahim", 30.0);
	        Stuff stuff = new Stuff("Abdul", 5.0);

	        // printing information
	        System.out.println("Student Information:");
	        System.out.println("Name: " + student.getName());
	        System.out.println("Student ID: " + student.getStudentId());
	        System.out.println("Salary: $" + student.getSalary()); 
	        student.study(); 

	        System.out.println("\nTeacher Information:");
	        System.out.println("Name: " + teacher.getName());
	        System.out.println("Salary per Hour: $" + teacher.getSalaryPerHour());
	        System.out.println("Salary: $" + teacher.getSalary()); 
	        teacher.teach(); 
	        System.out.println("\nStuff Information:");
	        System.out.println("Name: " + stuff.getName());
	        System.out.println("Salary per Hour: $" + stuff.getSalaryPerHour());
	        System.out.println("Salary: $" + stuff.getSalary()); 
	        stuff.serve();

	}


}
