package Accountin;

public abstract class Person_ab {

	private String name;

    // Constructor
    public void Person_ab(String name) {
        this.name = name;
    }

    public abstract double getSalary();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
