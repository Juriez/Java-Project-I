package Accountin;

public class person {
	public int sal;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("How are you?");
		System.err.println();
	}

}
