package Accountin;

public class Teacher extends Person_ab {

	   private double salaryPerHour;

	    // Constructor
	    public Teacher(String name, double salaryPerHour) {
	        super();
	        this.salaryPerHour = salaryPerHour;
	    }

	    @Override
	    public double getSalary() {
	        // Calculate salary based on hours worked (let's say 40 hours per week)
	        return salaryPerHour * 50;
	    }

	    public double getSalaryPerHour() {
	        return salaryPerHour;
	    }

	    public void setSalaryPerHour(double salaryPerHour) {
	        this.salaryPerHour = salaryPerHour;
	    }

	    public void teach() {
	        System.out.println(getName() + " is teaching.");
	    }

}
